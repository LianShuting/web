<?php
/**
 * 配置文件
 */
return array(
    'DB_TYPE' => 'mysql',
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'music1',
    'DB_USER' => 'root',
    'DB_PWD' => '',
    'DB_PORT' => '3306',
    'DB_PREFIX' => 'zb2017_',
    //密钥
    "AUTHCODE" => 'yo2ryCqofWCZjKpR0i',
    //cookies
    "COOKIE_PREFIX" => 'Jyam4L_',
);
