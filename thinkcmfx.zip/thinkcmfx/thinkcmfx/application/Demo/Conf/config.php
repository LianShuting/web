<?php

$runtime_home_config= array();
$configs= array(
		
);

return  array_merge($configs,$runtime_home_config);
